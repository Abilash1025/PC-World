﻿namespace PcWorld
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnorder = new System.Windows.Forms.Button();
            this.datepick1 = new System.Windows.Forms.DateTimePicker();
            this.niclbl = new System.Windows.Forms.Label();
            this.cstmrlbl = new System.Windows.Forms.Label();
            this.datepick2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btninvoice = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnorder
            // 
            this.btnorder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btnorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnorder.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnorder.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnorder.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnorder.Location = new System.Drawing.Point(425, 143);
            this.btnorder.Name = "btnorder";
            this.btnorder.Size = new System.Drawing.Size(116, 40);
            this.btnorder.TabIndex = 2;
            this.btnorder.Text = "Orders";
            this.btnorder.UseVisualStyleBackColor = false;
            this.btnorder.Click += new System.EventHandler(this.btnfind_Click);
            // 
            // datepick1
            // 
            this.datepick1.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.datepick1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepick1.Location = new System.Drawing.Point(301, 90);
            this.datepick1.Name = "datepick1";
            this.datepick1.Size = new System.Drawing.Size(220, 31);
            this.datepick1.TabIndex = 0;
            // 
            // niclbl
            // 
            this.niclbl.AutoSize = true;
            this.niclbl.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.niclbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.niclbl.Location = new System.Drawing.Point(108, 90);
            this.niclbl.Name = "niclbl";
            this.niclbl.Size = new System.Drawing.Size(127, 29);
            this.niclbl.TabIndex = 200;
            this.niclbl.Text = "Start Date";
            // 
            // cstmrlbl
            // 
            this.cstmrlbl.AutoSize = true;
            this.cstmrlbl.BackColor = System.Drawing.Color.Transparent;
            this.cstmrlbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cstmrlbl.Font = new System.Drawing.Font("Times New Roman", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cstmrlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(20)))), ((int)(((byte)(30)))));
            this.cstmrlbl.Location = new System.Drawing.Point(442, 0);
            this.cstmrlbl.Name = "cstmrlbl";
            this.cstmrlbl.Size = new System.Drawing.Size(143, 49);
            this.cstmrlbl.TabIndex = 192;
            this.cstmrlbl.Text = "Report";
            // 
            // datepick2
            // 
            this.datepick2.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold);
            this.datepick2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepick2.Location = new System.Drawing.Point(772, 90);
            this.datepick2.Name = "datepick2";
            this.datepick2.Size = new System.Drawing.Size(220, 31);
            this.datepick2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.label1.Location = new System.Drawing.Point(579, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 29);
            this.label1.TabIndex = 212;
            this.label1.Text = "End Date";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel3.Location = new System.Drawing.Point(-1, 70);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1158, 12);
            this.panel3.TabIndex = 213;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panel1.Location = new System.Drawing.Point(-27, 189);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1158, 10);
            this.panel1.TabIndex = 214;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.crystalReportViewer1);
            this.panel2.Location = new System.Drawing.Point(-1, 205);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1105, 558);
            this.panel2.TabIndex = 215;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(1105, 558);
            this.crystalReportViewer1.TabIndex = 0;
            // 
            // btninvoice
            // 
            this.btninvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.btninvoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninvoice.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninvoice.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btninvoice.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btninvoice.Location = new System.Drawing.Point(558, 143);
            this.btninvoice.Name = "btninvoice";
            this.btninvoice.Size = new System.Drawing.Size(116, 40);
            this.btninvoice.TabIndex = 3;
            this.btninvoice.Text = "Invoice";
            this.btninvoice.UseVisualStyleBackColor = false;
            this.btninvoice.Click += new System.EventHandler(this.btninvoice_Click);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1105, 765);
            this.Controls.Add(this.btninvoice);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.datepick2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnorder);
            this.Controls.Add(this.datepick1);
            this.Controls.Add(this.niclbl);
            this.Controls.Add(this.cstmrlbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form8";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form8";
            this.Load += new System.EventHandler(this.Form8_Load);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnorder;
        private System.Windows.Forms.DateTimePicker datepick1;
        private System.Windows.Forms.Label niclbl;
        private System.Windows.Forms.Label cstmrlbl;
        private System.Windows.Forms.DateTimePicker datepick2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btninvoice;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
    }
}