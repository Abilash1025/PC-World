﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PcWorld
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=pc_world;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        SqlCommand cmd;
        SqlDataAdapter dr;
        
        private void btnfind_Click(object sender, EventArgs e)
        {
          

            con.Open();
            DataTable dt = new DataTable();

            cmd = new SqlCommand("select * from orders where ordereddate between '" + datepick1.Value.Date+"' and '"+datepick2.Value.Date+"'",con);

            dr = new SqlDataAdapter(cmd);
            dr.Fill(dt);

            CrystalReport2 cr = new CrystalReport2();
            cr.Database.Tables["orders"].SetDataSource(dt);

            this.crystalReportViewer1.ReportSource = cr;

            con.Close();
        }

        private void btninvoice_Click(object sender, EventArgs e)
        {
            con.Open();
            DataTable dt1 = new DataTable();

            cmd = new SqlCommand("select * from payment where patdate between '" + datepick1.Value.Date + "' and '" + datepick2.Value.Date + "'", con);

            dr = new SqlDataAdapter(cmd);
            dr.Fill(dt1);

            CrystalReport3 cr1 = new CrystalReport3();
            cr1.Database.Tables["payment"].SetDataSource(dt1);

            this.crystalReportViewer1.ReportSource = cr1;

            con.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
