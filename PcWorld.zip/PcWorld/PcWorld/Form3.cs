﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcWorld
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to logout?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Form2 f2 = new Form2();
                f2.Show();
                this.Show();
                this.Hide();
            }
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnproduct_Click(object sender, EventArgs e)
        {
            panel4.Controls.Clear();
            Form4 f4 = new Form4();
            f4.TopLevel = false;
            panel4.Controls.Add(f4);
            f4.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            f4.Dock = DockStyle.Fill;
            f4.Show();
        }

        private void btnorders_Click(object sender, EventArgs e)
        {
            panel4.Controls.Clear();
            
            Form5 f5 = new Form5();
            f5.TopLevel = false;
            panel4.Controls.Add(f5);
            f5.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            f5.Dock = DockStyle.Fill;
            f5.Show();
        }

        private void btncustomer_Click(object sender, EventArgs e)
        {
            panel4.Controls.Clear();
            Form6 f6 = new Form6();
            f6.TopLevel = false;
            panel4.Controls.Add(f6);
            f6.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            f6.Dock = DockStyle.Fill;
            f6.Show();
        }

        private void btnpayment_Click(object sender, EventArgs e)
        {
            panel4.Controls.Clear();
            Form7 f7 = new Form7();
            f7.TopLevel = false;
            panel4.Controls.Add(f7);
            f7.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            f7.Dock = DockStyle.Fill;
            f7.Show();
        }

        private void btnreports_Click(object sender, EventArgs e)
        {
            panel4.Controls.Clear();
            Form8 f8 = new Form8();
            f8.TopLevel = false;
            panel4.Controls.Add(f8);
            f8.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            f8.Dock = DockStyle.Fill;
            f8.Show();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label1.Text = Form2.Username;
            if (label1.Text == "Order-Clerk")
            {
                
                btnpayment.Enabled = false;
                btnreports.Enabled = false;
            }
            if (label1.Text == "Chief-Account")
            {

                btnproduct.Enabled = false;
                btnorders.Enabled = false;
                btncustomer.Enabled = false;
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
