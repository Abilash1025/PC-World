﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PcWorld
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            filldata();
            filldata1();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=pc_world;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from customers", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void filldata1()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from customers", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView2.DataSource = dttbl;

            con.Close();
        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (txtcid.Text == "" || txtcust.Text == "" || txtnic.Text == "" || txtphone.Text == "" ||
          txtmail.Text == "" || txtadd.Text == "" || cmbtype.Text == "" || datereg.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "Insert into customers values('" + txtcid.Text + "','" + txtcust.Text + "','" + txtnic.Text + "','" +
                    int.Parse(txtphone.Text) + "','" + txtmail.Text + "','" + txtadd.Text + "','" + cmbtype.Text+ "','" +
                     datereg.Value.Date + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Customer database", "Message");
                txtcid.Clear();
                txtcust.Clear();
                txtnic.Clear();
                txtphone.Clear();
                txtmail.Clear();
                txtadd.Clear();
                cmbtype.ResetText();
                datereg.ResetText();

            }
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtcid.Text == "" || txtcust.Text == "" || txtnic.Text == "" || txtphone.Text == "" ||
txtmail.Text == "" || txtadd.Text == "" || cmbtype.Text == "" || datereg.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "update customers set customername='" + txtcust.Text + "',nic='" + txtnic.Text + "',mobileno='" +
                    int.Parse(txtphone.Text) + "',email='" + txtmail.Text + "',address='" + txtadd.Text + "',type='" +
                    cmbtype.Text + "',registdate='" + datereg.Value.Date + "' where customerid='"+txtcid.Text+"'";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully updated Customer database", "Message");
                txtcid.Clear();
                txtcust.Clear();
                txtnic.Clear();
                txtphone.Clear();
                txtmail.Clear();
                txtadd.Clear();
                cmbtype.ResetText();
                datereg.ResetText();

            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtcid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtcust.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtnic.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtphone.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtmail.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtadd.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            cmbtype.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            datereg.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
          
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtcid.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                String customerid = txtcid.Text;
                con.Open();
                string delete = "delete from customers where customerid='" + customerid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                    txtcid.Clear();
                    txtcust.Clear();
                    txtnic.Clear();
                    txtphone.Clear();
                    txtmail.Clear();
                    txtadd.Clear();
                    cmbtype.ResetText();
                    datereg.ResetText();
                }
                con.Close();
                
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            txtcid.Clear();
            txtcust.Clear();
            txtnic.Clear();
            txtphone.Clear();
            txtmail.Clear();
            txtadd.Clear();
            cmbtype.ResetText();
            datereg.ResetText();

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtcid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtcust.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtnic.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            txtphone.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            txtmail.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
            txtadd.Text = dataGridView2.CurrentRow.Cells[5].Value.ToString();
            cmbtype.Text = dataGridView2.CurrentRow.Cells[6].Value.ToString();
            datereg.Text = dataGridView2.CurrentRow.Cells[7].Value.ToString();

            panel6.Visible = true;
        }
    }
}
