﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcWorld
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public static string Username, Password;
        private void exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult dialogresult = MessageBox.Show("Are Your Going to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            if (dialogresult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            
            Username = usrnametxtbx.Text;
            Password = passwrdtxtbx.Text;

            if (Username == "Order-Clerk" && Password == "stark")
            {
                MessageBox.Show("Accessing granted", "Login");
                progressBar1.Visible = true;
                timer1.Start();
            }
            else if (Username == "Chief-Account" && Password == "stark")
            {
                MessageBox.Show("Accessing Granted", "Login");
                progressBar1.Visible = true;
                timer1.Start();
            }
            else if (Username == "Production-Manager" && Password == "stark")
            {
                MessageBox.Show("Accessing Granted", "Login");
                progressBar1.Visible = true;
                timer1.Start();
            }
            else 
            {
                MessageBox.Show("Invalid username or password", "Configuration", MessageBoxButtons.OK, MessageBoxIcon.Error);

                usrnametxtbx.Clear();
                passwrdtxtbx.Clear();
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            progressBar1.Visible = false;
            
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value = progressBar1.Value + 10;

            }
            else
            {
                timer1.Enabled = false;
                Form3 f3 = new Form3();
                f3.Show();
                this.Hide();
            }
        }

        private void passwordchckbx_CheckedChanged(object sender, EventArgs e)
        {
            if (passwordchckbx.Checked == true)
            {
                passwrdtxtbx.PasswordChar = '\0';
            }
            if (passwordchckbx.Checked == false)
            {
                passwrdtxtbx.PasswordChar = '*';
            }
        }

        private void usrnametxtbx_Click(object sender, EventArgs e)
        {
            namelbl.ForeColor = Color.White;
            pictureBox2.Visible = false;
            panel3.BackColor = Color.White;
        }

        private void passwrdtxtbx_Click(object sender, EventArgs e)
        {
            passwrdlbl.ForeColor = Color.White;
            pictureBox4.Visible = false;
            panel5.BackColor = Color.White;
        }
    }

    }

