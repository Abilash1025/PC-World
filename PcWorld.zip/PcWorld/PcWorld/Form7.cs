﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
    

namespace PcWorld
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
            filldata();
            filldata1();
            filldata2();
        }


        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=pc_world;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);


        private void niclbl_Click(object sender, EventArgs e)
        {

        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from payment", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }

        private void filldata1()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from payment", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView2.DataSource = dttbl;

            con.Close();
        }

        private void filldata2()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from orders", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView3.DataSource = dttbl;

            con.Close();
        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (txtpayid.Text == "" || txtoid.Text == "" || txtpname.Text == "" || txttype.Text == "" ||
                txtquantity.Text == "" || txtamount.Text == "" || txtcust.Text == "" || txtphone.Text == "" || txtworth.Text == "" || cmbtype.Text == "" ||
                datepay.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "Insert into payment values('" + txtpayid.Text + "','" + txtoid.Text + "','" + txtpname.Text + "','" +
                   txttype.Text + "','" + int.Parse(txtquantity.Text) + "','" + txtamount.Text + "','" + txtcust.Text + "','" +
                   int.Parse(txtphone.Text) + "','" + txtworth.Text + "','" + cmbtype.Text + "','" + datepay.Value.Date + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in payment database", "Message");
                txtoid.Clear();
                txtpayid.Clear();
                txtpname.Clear();
                txtquantity.Clear();
                txttype.Clear();
                txtamount.Clear();
                datepay.ResetText();
                txtcust.Clear();
                txtphone.Clear();
                txtworth.Clear();
                cmbtype.ResetText();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtpayid.Text == "" || txtoid.Text == "" || txtpname.Text == "" || txttype.Text == "" ||
    txtquantity.Text == "" || txtamount.Text == "" || txtcust.Text == "" || txtphone.Text == "" || txtworth.Text == "" || cmbtype.Text == "" ||
    datepay.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "update payment set orderid='" + txtoid.Text + "',productname='" + txtpname.Text + "',type='" +
                   txttype.Text + "',quantity='" + int.Parse(txtquantity.Text) + "',amount='" + txtamount.Text + "',customername='" + 
                   txtcust.Text + "',mobileno='" +int.Parse(txtphone.Text) + "',worth='" + txtworth.Text + "',paytype='" +
                   cmbtype.SelectedText + "',patdate='" + datepay.Value.Date + "' where paymentid='"+txtpayid.Text+"'";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully update payment database", "Message");
                txtoid.Clear();
                txtpayid.Clear();
                txtpname.Clear();
                txtquantity.Clear();
                txttype.Clear();
                txtamount.Clear();
                datepay.ResetText();
                txtcust.Clear();
                txtphone.Clear();
                txtworth.Clear();
                cmbtype.ResetText();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            txtoid.Clear();
            txtpayid.Clear();
            txtpname.Clear();
            txtquantity.Clear();
            txttype.Clear();
            txtamount.Clear();
            datepay.ResetText();
            txtcust.Clear();
            txtphone.Clear();
            txtworth.Clear();
            cmbtype.ResetText();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtpayid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtoid.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtpname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txttype.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtquantity.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtamount.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtcust.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtphone.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtworth.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            cmbtype.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            datepay.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtpayid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtoid.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtpname.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            txttype.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            txtquantity.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
            txtamount.Text = dataGridView2.CurrentRow.Cells[5].Value.ToString();
            txtcust.Text = dataGridView2.CurrentRow.Cells[6].Value.ToString();
            txtphone.Text = dataGridView2.CurrentRow.Cells[7].Value.ToString();
            txtworth.Text = dataGridView2.CurrentRow.Cells[8].Value.ToString();
            cmbtype.Text = dataGridView2.CurrentRow.Cells[9].Value.ToString();
            datepay.Text = dataGridView2.CurrentRow.Cells[10].Value.ToString();
            panel6.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            panel6.Visible = false;
            panel2.Visible = false;

           
       

        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

        private void dataGridView3_DoubleClick(object sender, EventArgs e)
        {
            txtoid.Text = dataGridView3.CurrentRow.Cells[0].Value.ToString();
            txtpname.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
            txtquantity.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();
            txttype.Text = dataGridView3.CurrentRow.Cells[4].Value.ToString();
            txtamount.Text = dataGridView3.CurrentRow.Cells[5].Value.ToString();
            txtcust.Text = dataGridView3.CurrentRow.Cells[8].Value.ToString();
            txtphone.Text = dataGridView3.CurrentRow.Cells[9].Value.ToString();
            txtworth.Text = dataGridView3.CurrentRow.Cells[10].Value.ToString();
            panel2.Visible = false;
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            new Form9(txtoid.Text,txtpayid.Text,txtpname.Text,txttype.Text,txtquantity.Text,txtcust.Text,txtphone.Text,cmbtype.Text,datepay.Text,txtamount.Text).ShowDialog();
            


        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtpayid.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                String payid = txtpayid.Text;
                con.Open();
                string delete = "delete from payment where paymentid='" + payid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                    txtoid.Clear();
                    txtpayid.Clear();
                    txtpname.Clear();
                    txtquantity.Clear();
                    txttype.Clear();
                    txtamount.Clear();
                    datepay.ResetText();
                    txtcust.Clear();
                    txtphone.Clear();
                    txtworth.Clear();
                    cmbtype.ResetText();
                }
                con.Close();

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }
    }
}
