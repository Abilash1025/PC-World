﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PcWorld
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            filldata();
            filldata1();
            filldata2();
            filldata3();

        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=pc_world;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);
        private void Form5_Load(object sender, EventArgs e)
        {
            panel6.Visible = false;
            panel7.Visible = false;
            panel8.Visible = false;
       
        }
        private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from orders", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void filldata3()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from customers", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView4.DataSource = dttbl;

            con.Close();
        }
        private void filldata2()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from products", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView3.DataSource = dttbl;

            con.Close();
        }
        private void filldata1()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from orders", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView2.DataSource = dttbl;

            con.Close();
        }
        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (txtoid.Text == "" || txtpid.Text == "" || txtpname.Text == "" || txttype.Text == "" ||
                txtquantity.Text == "" || txtamount.Text == "" || dateorder.Text == "" || datedelivery.Text == "" || txtcust.Text == "" || txtworth.Text == "" ||
                txtphone.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "Insert into orders values('" + txtoid.Text + "','" + txtpid.Text + "','" + txtpname.Text + "','" +
                   int.Parse(txtquantity.Text) + "','" + txttype.Text + "','"+txtamount.Text+"','" + dateorder.Value.Date + "','" +
                    datedelivery.Value.Date + "','" + txtcust.Text + "','" + int.Parse(txtphone.Text) + "','" + txtworth.Text + "');update products set quantity=quantity-'"+int.Parse(txtquantity.Text)+"' where productid='"+txtpid.Text+"'";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in database", "Message");
                txtoid.Clear();
                txtpid.Clear();
                txtpname.Clear();
                txtquantity.Clear();
                txttype.Clear();
                txtamount.Clear();
                dateorder.ResetText();
                datedelivery.ResetText();
                txtcust.Clear();
                txtphone.Clear();
                txtworth.Clear();
            }
        }

        private void txtseries_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            filldata();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtoid.Text == "" || txtpid.Text == "" || txtpname.Text == "" || txttype.Text == "" ||
                txtquantity.Text == "" || txtamount.Text == "" || dateorder.Text == "" || datedelivery.Text == "" || txtcust.Text == "" || txtworth.Text == "" ||
                txtphone.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "update orders set productid='"+txtpid.Text+"',productname='" + txtpname.Text + "',quantity='" +
                int.Parse(txtquantity.Text) + "',amount='"+txtamount.Text+"',ordereddate='" +dateorder.Value.Date + "',delivereddate='" +datedelivery.Value.Date+ "',customername='" +
                txtcust.Text + "',mobileno='" +int.Parse(txtphone.Text)+ "',worth='" + txtworth.Text + "' where orderid='" + txtoid.Text + "'";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully Updated order database", "Message");
                txtoid.Clear();
                txtpid.Clear();
                txtpname.Clear();
                txtquantity.Clear();
                txttype.Clear();
                txtamount.Clear();
                dateorder.ResetText();
                datedelivery.ResetText();
                txtcust.Clear();
                txtphone.Clear();
                txtworth.Clear();

            }

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtoid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtpid.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtpname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtquantity.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txttype.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtamount.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            dateorder.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            datedelivery.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtcust.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtphone.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtworth.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            
        }
        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {

        }
        private void dataGridView3_DoubleClick(object sender, EventArgs e)
        {
   


        }
        private void dataGridView4_DoubleClick(object sender, EventArgs e)
        {

        }


        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtoid.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
                String orderid = txtoid.Text;
                con.Open();
                string delete = "delete from orders where orderid='" + orderid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                    txtoid.Clear();
                    txtpid.Clear();
                    txtpname.Clear();
                    txtquantity.Clear();
                    txttype.Clear();
                    txtamount.Clear();
                    dateorder.ResetText();
                    datedelivery.ResetText();
                    txtcust.Clear();
                    txtphone.Clear();
                    txtworth.Clear();
                }
                con.Close();
         
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            txtoid.Clear();
            txtpid.Clear();
            txtpname.Clear();
            txtquantity.Clear();
            txttype.Clear();
            txtamount.Clear();
            dateorder.ResetText();
            datedelivery.ResetText();
            txtcust.Clear();
            txtphone.Clear();
            txtworth.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            panel8.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel7.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel8.Visible = false;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            panel7.Visible = true;
        }

        private void button2_Click_2(object sender, EventArgs e)
        {

        }

        private void button2_Click_3(object sender, EventArgs e)
        {
            panel7.Visible = true;
        }

        private void dataGridView3_DoubleClick_1(object sender, EventArgs e)
        {

            txtpid.Text = dataGridView3.CurrentRow.Cells[0].Value.ToString();
            txtpname.Text = dataGridView3.CurrentRow.Cells[1].Value.ToString();
           
            txttype.Text = dataGridView3.CurrentRow.Cells[5].Value.ToString();
            panel7.Visible = false;
        }

        private void dataGridView4_DoubleClick_1(object sender, EventArgs e)
        {

            txtcust.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            txtphone.Text = dataGridView4.CurrentRow.Cells[3].Value.ToString();
            txtworth.Text = dataGridView4.CurrentRow.Cells[4].Value.ToString();
           
        }

        private void dataGridView4_DoubleClick_2(object sender, EventArgs e)
        {

            txtcust.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            txtphone.Text = dataGridView4.CurrentRow.Cells[3].Value.ToString();
            txtworth.Text = dataGridView4.CurrentRow.Cells[4].Value.ToString();
            panel8.Visible = false;
        }

        private void dataGridView2_DoubleClick_1(object sender, EventArgs e)
        {
            txtoid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtpid.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtpname.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            txtquantity.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            txttype.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
            txtamount.Text = dataGridView2.CurrentRow.Cells[5].Value.ToString();
            dateorder.Text = dataGridView2.CurrentRow.Cells[6].Value.ToString();
            datedelivery.Text = dataGridView2.CurrentRow.Cells[7].Value.ToString();
            txtcust.Text = dataGridView2.CurrentRow.Cells[8].Value.ToString();
            txtphone.Text = dataGridView2.CurrentRow.Cells[9].Value.ToString();
            txtworth.Text = dataGridView2.CurrentRow.Cells[10].Value.ToString();
            panel6.Visible = false;
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            new Form10(txtoid.Text,txtpname.Text,txtquantity.Text,txtamount.Text,dateorder.Text,datedelivery.Text,txtcust.Text,txtphone.Text).ShowDialog();
        }
    }
}
