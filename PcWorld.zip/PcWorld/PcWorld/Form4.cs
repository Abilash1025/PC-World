﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PcWorld
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            filldata();
            filldata1();
        }
        static string connection = @"Data Source=ABI\SQLEXPRESS;Initial Catalog=pc_world;Integrated Security=True";
        SqlConnection con = new SqlConnection(connection);

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (txtpid.Text == "" || txtpname.Text== "" || txtcompany.Text == "" || txtseries.Text == "" ||
                txttype.Text == "" || datetake.Text == "" || txtamount.Text == "" || txtseller.Text == "" ||  txtnum.Text == "" ||
                txtmail.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {
                         
                con.Open();
                string insert = "Insert into products values('"+txtpid.Text+ "','" + txtpname.Text + "','" + txtcompany.Text + "','" +
                    txtseries.Text + "','" +int.Parse(txtquantity.Text) + "','" + txttype.Text + "','" + datetake.Value.Date + "','" +
                    txtamount.Text + "','" +txtseller.Text + "','" + int.Parse(txtnum.Text) + "','" + txtmail.Text + "')";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully saved in Product database", "Message");
                txtpid.Clear();
                txtpname.Clear();
                txtcompany.Clear();
                txtseries.Clear();
                txtquantity.Clear();
                txttype.ResetText();
                datetake.ResetText();
                txtamount.Clear();
                txtseller.Clear();
                txtnum.Clear();
                txtmail.Clear();
            }

        }
       private void filldata()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from products", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView1.DataSource = dttbl;

            con.Close();
        }
        private void filldata1()
        {
            con.Open();

            SqlDataAdapter dtadpt = new SqlDataAdapter("select * from products", con);
            DataTable dttbl = new DataTable();
            dtadpt.Fill(dttbl);
            dataGridView2.DataSource = dttbl;

            con.Close();
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
           filldata();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtpid.Text == "" || txtpname.Text == "" || txtcompany.Text == "" || txtseries.Text == "" ||
     txttype.Text == "" || datetake.Text == "" || txtamount.Text == "" || txtseller.Text == "" || txtnum.Text == "" ||
     txtmail.Text == "")
            {
                MessageBox.Show("Please fill the all blanks", "Alert");
            }
            else
            {

                con.Open();
                string insert = "update products set productname='" + txtpname.Text + "',company='" + txtcompany.Text + "',series='" +
                    txtseries.Text + "',quantity='" + int.Parse(txtquantity.Text) + "',type='" + txttype.SelectedText + "',publisheddate='" +
                    datetake.Value.Date + "',Amount='" +txtamount.Text + "',sellename='" + txtseller.Text + "',mobileno='" + 
                    int.Parse(txtnum.Text) + "',email='" + txtmail.Text + "' where productid='"+txtpid.Text +"'";
                SqlCommand cmd = new SqlCommand(insert, con);
                cmd.ExecuteNonQuery();

                con.Close();

                MessageBox.Show("successfully Updated in Product database", "Message");
                txtpid.Clear();
                txtpname.Clear();
                txtcompany.Clear();
                txtseries.Clear();
                txtquantity.Clear();
                txttype.ResetText();
                datetake.ResetText();
                txtamount.Clear();
                txtseller.Clear();
                txtnum.Clear();
                txtmail.Clear();
            }

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtpid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtpname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtcompany.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtseries.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtquantity.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txttype.SelectedText = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            datetake.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtamount.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtseller.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtnum.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtmail.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtpid.Text == "")
            {
                MessageBox.Show("Please fill the ID", "Alert");
            }
            else
            {
              String  productid = txtpid.Text;
                con.Open();
                string delete = "delete from products where productid='" + productid + "'";
                if (MessageBox.Show("Are you sure to delete data?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                    return;
                }
                else
                {
                    SqlCommand cmd = new SqlCommand(delete, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Deleted", "Message");
                }
                con.Close();
                txtpid.Clear();
                txtpname.Clear();
                txtcompany.Clear();
                txtseries.Clear();
                txtquantity.Clear();
                txttype.ResetText();
                datetake.ResetText();
                txtamount.Clear();
                txtseller.Clear();
                txtnum.Clear();
                txtmail.Clear();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            txtpid.Clear();
            txtpname.Clear();
            txtcompany.Clear();
            txtseries.Clear();
            txtquantity.Clear();
            txttype.ResetText();
            datetake.ResetText();
            txtamount.Clear();
            txtseller.Clear();
            txtnum.Clear();
            txtmail.Clear();
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            txtpid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txtpname.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txtcompany.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            txtseries.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            txtquantity.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
            txttype.SelectedText = dataGridView2.CurrentRow.Cells[5].Value.ToString();
            datetake.Text = dataGridView2.CurrentRow.Cells[6].Value.ToString();
            txtamount.Text = dataGridView2.CurrentRow.Cells[7].Value.ToString();
            txtseller.Text = dataGridView2.CurrentRow.Cells[8].Value.ToString();
            txtnum.Text = dataGridView2.CurrentRow.Cells[9].Value.ToString();
            txtmail.Text = dataGridView2.CurrentRow.Cells[10].Value.ToString();
            panel6.Visible = false;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

   
    }
}
