﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PcWorld
{
    public partial class Form10 : Form
    {
        private string text1;
        private string text2;
        private string text3;
        private string text4;
        private string text5;
        private string text6;
        private string text7;
        private string text8;

        public Form10()
        {
            
        }

        public Form10(string text1, string text2, string text3, string text4, string text5, string text6, string text7, string text8)
        {
            InitializeComponent();
            this.text1 = text1;
            this.text2 = text2;
            this.text3 = text3;
            this.text4 = text4;
            this.text5 = text5;
            this.text6 = text6;
            this.text7 = text7;
            this.text8 = text8;
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            CrystalReport5 rpt = new CrystalReport5();
            rpt.SetParameterValue("Oid", text2);
            rpt.SetParameterValue("pname", text1);
            rpt.SetParameterValue("quan", text3);
            rpt.SetParameterValue("amount", text4);
            rpt.SetParameterValue("odate", text5);
            rpt.SetParameterValue("ddate", text6);
            rpt.SetParameterValue("cname", text7);
            rpt.SetParameterValue("phone", text8);
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();
        }
    }
}
